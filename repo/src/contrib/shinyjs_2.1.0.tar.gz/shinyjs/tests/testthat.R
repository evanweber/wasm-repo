library(testthat)
library(shinyjs)

test_check("shinyjs")
