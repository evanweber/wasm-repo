# text is wrapped

    Code
      local({
        cli_div(class = "testcli", theme = test_style())
        cli_h1("Header")
        cli_text(lorem_ipsum())
      })
    Message
      
      Header
      
      Duis quis magna incididunt nulla commodo minim non
      exercitation nostrud ullamco dolor exercitation ut veniam.
      Fugiat irure tempor commodo voluptate ut. In et tempor
      excepteur quis. Qui et nisi ad quis ad cupidatat tempor
      laborum est excepteur aliqua veniam. Velit sunt magna
      veniam Lorem elit enim et pariatur. Occaecat mollit
      consequat dolore in. Veniam officia labore reprehenderit
      culpa dolore quis nisi do aliqua commodo deserunt.
      Cupidatat nostrud ad est in ad laboris consectetur esse
      minim. Irure do anim anim ea mollit ad cupidatat ullamco
      ullamco nulla elit in. Lorem Lorem deserunt deserunt et ut
      velit nulla nulla ipsum ad laborum quis.

