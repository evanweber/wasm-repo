rad2deg <- function(r){
  r * 57.29577951308232286465 # double for 180/pi
}

deg2rad <- function(d){
  d * 0.01745329251994329547437 # double for pi/180
}
