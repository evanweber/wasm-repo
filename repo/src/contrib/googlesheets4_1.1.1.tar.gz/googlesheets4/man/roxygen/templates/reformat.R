#' @param reformat Logical, indicates whether to reformat the affected cells.
#'   Currently googlesheets4 provides no real support for formatting, so
#'   `reformat = TRUE` effectively means that edited cells become unformatted.
